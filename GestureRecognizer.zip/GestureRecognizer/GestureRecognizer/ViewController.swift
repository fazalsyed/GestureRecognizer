//
//  ViewController.swift
//  GestureRecognizer
//
//  Created by syed fazal abbas on 10/05/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var vw: UIView!
    @IBOutlet var lblMessage: UILabel!
    @IBOutlet var pinchgesture: UIPinchGestureRecognizer!
    @IBOutlet var rotationGesture: UIRotationGestureRecognizer!
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
    }
    func setupUI(){
        vw.layer.cornerRadius = 10
        vw.layer.masksToBounds = true
        vw.clipsToBounds = false
    }

    @IBAction func tappedGesture(_ sender: UISwipeGestureRecognizer) {
        switch sender.direction{
        case .up:
            lblMessage.text = "Upper Direction"
            vw.backgroundColor = UIColor.red
        case .down:
            lblMessage.text = "Down Direction"
            vw.backgroundColor = UIColor.blue
        case .left:
            lblMessage.text = "Left Direction"
            vw.backgroundColor = UIColor.yellow
        case .right:
            lblMessage.text = "Right Direction"
            vw.backgroundColor = UIColor.orange
        default:
            lblMessage.text = "Default value"
        }
    }
    
    @IBAction func pinchRecognizer(_ sender: UIPinchGestureRecognizer) {
        guard let gestureView = pinchgesture.view else{
            return
        }
        gestureView.transform = gestureView.transform.scaledBy(x: pinchgesture.scale, y: pinchgesture.scale)
        pinchgesture.scale = 1
    }
    
    @IBAction func tappedRotationGesture(_ sender: UIRotationGestureRecognizer) {
        guard let gestureView = rotationGesture.view else{
            return
        }
        gestureView.transform = gestureView.transform.rotated(by: rotationGesture.rotation)
        rotationGesture.rotation = 0
    }
}

